#pragma once

#pragma once

#include "Point.h"

struct Rect {
    const struct Figure figure;
    const struct Point point1;
    const struct Point point2;
};

extern const void* Rect;
