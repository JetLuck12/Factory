#pragma once

#include "Figure.h"

struct Point {
    const struct Figure _;
    int x;
    int y;
};

extern const void* PPoint;