#pragma once
#include "Dyn_arr.h"

void get_figures(Darray* Figure_array, FILE* fp);
void draw_figures(Darray* figure_array);

