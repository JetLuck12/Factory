#pragma once

#include "Class.h"

struct Figure {
    const void *class;
};

extern const void* Figure;