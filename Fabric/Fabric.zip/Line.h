#pragma once

#include "Point.h"

struct Line {
    const struct Figure _;
    const struct Point point1;
    const struct Point point2;
};

extern const void* Line;

